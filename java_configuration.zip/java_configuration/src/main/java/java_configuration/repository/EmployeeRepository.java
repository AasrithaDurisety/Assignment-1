package java_configuration.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java_configuration.module.Employee;
import java_configuration.util.EmployeeRowMapper;

@Repository
public class EmployeeRepository {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public void save(Employee employee) {
		String sql = "insert into appointment values(?,?,?,?)";
		jdbcTemplate.update(sql, new Object[] {employee.getId(), employee.getName(), employee.getRole()});
	}

	public List<Object> getAllEmployees() {
		String query = "select id, name, role from Employee";
		return jdbcTemplate.query(query, new EmployeeRowMapper());
	}

	public Employee getEmployee(int id) {
		String query = "select id, name, role from Employee where id = " + id;
		
		return (Employee) jdbcTemplate.query(query, new EmployeeRowMapper()).get(0);
	}

	public void updateEmployee(Employee employee) {
		
		String query = "update Employee set name=?, role=? where id=?";
		int out = jdbcTemplate.update(query, employee.getName(), employee.getRole(), employee.getId());
		if(out!=0)
			System.out.println("Employee updated with id : " + employee.getId());
		else
			System.out.println("No Employee found with id : " + employee.getId());
		
	}

	public void deleteEmployee(int employeeId) {
		
		String query = "delete from Employee where id = ?";
		int out = jdbcTemplate.update(query, employeeId);
		if(out!=0)
			System.out.println("Employee deleted with id : " + employeeId);
		else
			System.out.println("No Employee found with id : " + employeeId);
		
	}

}
