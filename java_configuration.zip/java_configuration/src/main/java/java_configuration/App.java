package java_configuration;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java_configuration.config.BeanConfig;
import java_configuration.module.Employee;
import java_configuration.service.EmployeeService;

public class App {
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(BeanConfig.class);
		context.registerShutdownHook();
	    
	    EmployeeService employeeService = context.getBean(EmployeeService.class);
	    
	    Employee newEmployee = new Employee();
        newEmployee.setName("Mahesh");
        newEmployee.setRole("HR");
        try {
			employeeService.save(newEmployee);
		} catch (Exception e) {
			e.printStackTrace();
		}

        // Get all employees
        System.out.println("All Employees:");
        List<Object> allEmployees = employeeService.getAllEmployees();
        for (Object employee : allEmployees) {
            System.out.println(employee);
        }

        // Update employee
        Employee existingEmployee = employeeService.getEmployee(993);
        if (existingEmployee != null) {
            existingEmployee.setName("Updated Name");
            employeeService.updateEmployee(existingEmployee);
            System.out.println("Employee updated successfully.");
        }

        // Delete employee
        int employeeIdToDelete = 993;
        employeeService.deleteEmployee(employeeIdToDelete);
        System.out.println("Employee with ID " + employeeIdToDelete + " deleted.");

        // Display the updated list of employees
        System.out.println("Updated Employee List:");
        List<Object> updatedEmployees = employeeService.getAllEmployees();
        for (Object employee : updatedEmployees) {
            System.out.println(employee);
        }
	    context.close();
		
	}

}
