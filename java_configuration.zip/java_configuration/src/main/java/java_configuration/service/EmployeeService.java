package java_configuration.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java_configuration.module.Employee;
import java_configuration.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepository repo;
	
	@Transactional
	public void save(Employee employee) throws Exception {
		repo.save(employee);
	}

	@Transactional
	public List<Object> getAllEmployees() {
		return repo.getAllEmployees();
	}

	@Transactional
	public Employee getEmployee(int id) {
		return repo.getEmployee(id);
	}

	@Transactional
	public void updateEmployee(Employee employee) {
		repo.updateEmployee(employee);
	}

	@Transactional
	public void deleteEmployee(int employeeId) {
		repo.deleteEmployee(employeeId);
	}

}
