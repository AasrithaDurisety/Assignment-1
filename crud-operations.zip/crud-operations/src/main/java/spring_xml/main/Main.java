package spring_xml.main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import spring_xml.model.Employee;
import spring_xml.service.EmployeeService;

public class Main {

	  public static void main(String[] args) {
	        // Load the Spring context
	        ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml");

	        // Retrieve the EmployeeService bean
	        EmployeeService employeeService = (EmployeeService) context.getBean("employeeService");

	        // Perform CRUD operations
	        // Add employee
	        Employee newEmployee = new Employee();
	        newEmployee.setName("Mahesh");
	        newEmployee.setRole("HR");
	        employeeService.addEmployee(newEmployee);

	        // Get all employees
	        System.out.println("All Employees:");
	        List<Employee> allEmployees = employeeService.getAllEmployees();
	        for (Employee employee : allEmployees) {
	            System.out.println("ID: " + employee.getId() + ", Name: " + employee.getName() + ", Role: " + employee.getRole());
	        }

	        // Update employee
	        Employee existingEmployee = employeeService.getEmployee(993);
	        if (existingEmployee != null) {
	            existingEmployee.setName("Updated Name");
	            employeeService.updateEmployee(existingEmployee);
	            System.out.println("Employee updated successfully.");
	        }

	        // Delete employee
	        int employeeIdToDelete = 993;
	        employeeService.deleteEmployee(employeeIdToDelete);
	        System.out.println("Employee with ID " + employeeIdToDelete + " deleted.");

	        // Display the updated list of employees
	        System.out.println("Updated Employee List:");
	        List<Employee> updatedEmployees = employeeService.getAllEmployees();
	        for (Employee employee : updatedEmployees) {
	            System.out.println("ID: " + employee.getId() + ", Name: " + employee.getName() + ", Role: " + employee.getRole());
	        }
	    }
	
}
