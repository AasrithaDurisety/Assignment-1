package spring_xml.dao;

import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import spring_xml.model.Employee;

public class EmployeeDao {
	
	private JdbcTemplate jdbcTemplate;

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Employee> getAllEmployees() {
        String sql = "SELECT * FROM employee";
        return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Employee.class));
    }

    public void addEmployee(Employee employee) {
        String sql = "INSERT INTO employee (id,name,role) VALUES (?,?,?)";
        jdbcTemplate.update(sql, employee.getId(),employee.getName(),employee.getRole());
    }

    public Employee getEmployee(int id) {
        String sql = "SELECT * FROM employee WHERE id=?";
        return jdbcTemplate.queryForObject(sql, new Object[]{id}, new BeanPropertyRowMapper<>(Employee.class));
    }

    public void updateEmployee(Employee employee) {
        String sql = "UPDATE employee SET name=? WHERE id=?";
        jdbcTemplate.update(sql, employee.getName(), employee.getId());
    }

    public void deleteEmployee(int id) {
        String sql = "DELETE FROM employee WHERE id=?";
        jdbcTemplate.update(sql, id);
    }

}
