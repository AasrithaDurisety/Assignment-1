package schedule_appointment.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import schedule_appointment.module.Appointment;
import schedule_appointment.repository.AppointmentRepository;

@Service
public class AppointmentService {
	
	@Autowired
	private AppointmentRepository repo;
	
	@Transactional
	public void save(Appointment appointment) throws Exception {
		
		if(repo.getCountOfAppointments(appointment.getDoctor_id()) <3)
			repo.save(appointment);
		else
			throw new Exception("Doctor has Maximum appointments");
	}

}
