package schedule_appointment;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import schedule_appointment.config.BeanConfig;
import schedule_appointment.module.Appointment;
import schedule_appointment.service.AppointmentService;

public class App {

	public static void main(String args[]) {
		
		 AnnotationConfigApplicationContext context =
	        		new AnnotationConfigApplicationContext(BeanConfig.class);
	    	context.registerShutdownHook();
	        
	        AppointmentService service = context.getBean(AppointmentService.class);
	        
	        Appointment appointment = new Appointment(1,1,"scheduled");
	        try {
	        service.save(appointment);
	        System.out.println("Appointment Scheduled");
	        }catch(Exception ex) {
	        	System.out.println("Rollback Happend because : " + ex.getMessage());
	        }
	        context.close();
	        
	}
	
}
