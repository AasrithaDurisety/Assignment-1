package schedule_appointment.module;

import java.util.Random;

public class Doctor {

	private int doctor_id;
	private String doctor_name;
	private String specialization;

	public Doctor() {
		super();
	}

	public Doctor(String name, String specialization) {
		super();
		this.doctor_id = new Random().nextInt(10000);
		this.doctor_name = name;
		this.specialization = specialization;
	}

	public int getDoctor_id() {
		return doctor_id;
	}

	public void setDoctor_id(int doctor_id) {
		this.doctor_id = doctor_id;
	}

	public String getName() {
		return doctor_name;
	}

	public void setName(String name) {
		this.doctor_name = name;
	}

	public String getSpecialization() {
		return specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	@Override
	public String toString() {
		return "Doctor [doctor_id=" + doctor_id + ", name=" + doctor_name + ", specialization=" + specialization
				+ "]";
	}
	
}
