package schedule_appointment.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import schedule_appointment.module.Appointment;

@Repository
public class AppointmentRepository {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public int getCountOfAppointments(int doctor_id) {
		String sql = "select count(appointment_id) from appointment where doctor_id = " + doctor_id;
		return jdbcTemplate.queryForObject(sql, Integer.class);
		
	}
	
	public void save(Appointment appointment) {
		String sql = "insert into appointment values(?,?,?,?)";
		jdbcTemplate.update(sql, new Object[] {appointment.getAppointment_id(), appointment.getDoctor_id(), appointment.getPatient_id(), appointment.getStatus()});
	}
	
}
